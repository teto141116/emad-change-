# eMaD Google Password Helper

Lightweight Android 16-compatible password-change assistant built with Kotlin, Jetpack Compose, Material 3 and Android WebView.

## Security

- No credentials, API keys, or secrets are stored in source control.
- Password fields are held in Compose state only for the current UI session.
- No password values are written to Logcat.
- WebView file/content access is disabled.
- Third-party cookies are disabled.
- WebView cache/history are cleared when the activity is destroyed.
- `.gitignore` excludes local Gradle/Android files and signing keys.

## Current workflow

1. Enter the current and new password in the app.
2. Enable the service.
3. Tap **Start Browser**.
4. Sign in to Google manually and complete CAPTCHA/2FA yourself.
5. Use Google's password-management page inside the embedded WebView.
6. Review and submit the password change yourself.
7. Use **Confirm Password Change** to trigger the local success notification.

The app deliberately does not inject passwords into Google's pages or automatically submit a Google password change.

## Build

Open the project in Android Studio with JDK 17, allow Gradle to sync, then run:

```bash
./gradlew assembleDebug
```

The debug APK is generated under:

```text
app/build/outputs/apk/debug/
```

## GitHub Actions

A workflow can be added later for automated debug/release builds. Do not commit keystores or credentials.
